# 一.文件结构
```
├── agora-player                拉流播放组件
│   ├── agora-player.js
│   ├── agora-player.json
│   ├── agora-player.wxml
│   └── agora-player.wxss
├── agora-pusher                推流组件
│   ├── agora-pusher.js
│   ├── agora-pusher.json
│   ├── agora-pusher.wxml
│   └── agora-pusher.wxss
├── common.wxss                 两个组件需要的wxss
├── images                      声网image
│   ├── cover.png
│   ├── error.png
│   ├── loading.png
│   ├── logo.png
│   └── network.png
├── mini-app-sdk-production.js  声网SDK
└── utils                       声网提供的工具类
    ├── config.js
    ├── layout.js
    └── util.js
```
# 二.集成指南
两个组件均为原生小程序组件,无须再次编译.
因此将整个dist目录改名为agora,放置到不经过编译的static/public文件夹下,直接引用即可

## mpVue
### 1.打开./utils/config.js
填写声网的APPID
### 2.app.json添加两个组件
// app.json
```
"usingComponents":{
    "agora-player":"/static/agora/agora-player/agora-player",
    "agora-pusher":"/static/agora/agora-pusher/agora-pusher"
}
```
### 3.使用
推流组件

agora-pusher

微信文档:https://developers.weixin.qq.com/miniprogram/dev/component/live-pusher.html
```
 <agora-pusher 
 v-if="item.type === 0 && !item.holding"                id="rtc-pusher" 
        :x="item.left" :y="item.top" :width="item.width" :height="item.height"
        :url="item.url" :muted="muted" :beauty="beauty" @bindpushfailed="onPusherFailed">
        </agora-pusher>
```
```
item为media数组的子项
    type:0为推流,1为拉流
    id:组件id
    x,y:左上坐标位置
    width,height:宽高
    url:推流地址。目前仅支持 rtmp 格式
    aspect:宽高比
    mode:SD（标清）, HD（高清）, FHD（超清）, RTC（实时通话）
    bindstatechange:状态时间变化回调
    bindnetstatus:网络状态回调
    muted:静音
    beauty:美颜

```
拉流播放组件

agora-player

微信文档:https://developers.weixin.qq.com/miniprogram/dev/component/live-player.html
```
<agora-player 
v-if="item.type === 1 && !item.holding" :id="'rtc-player-'+item.uid" 
:uid="item.uid"
         :x="item.left" :y="item.top" :width="item.width" :height="item.height"
           :url="item.url">
        </agora-player>
```

```
item为media数组的子项
    type:0为推流,1为拉流
    id:组件id
    x,y:左上坐标位置
    width,height:宽高
    url:拉流地址。目前仅支持 rtmp 格式
    uid:uid
```

其余资料,查看[wiki](https://wiki.51trust.com/pages/viewpage.action?pageId=17467463)




